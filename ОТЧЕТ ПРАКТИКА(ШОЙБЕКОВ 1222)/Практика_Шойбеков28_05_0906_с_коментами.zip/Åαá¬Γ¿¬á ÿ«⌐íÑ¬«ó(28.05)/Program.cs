﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_Шойбеков_28._05_
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Вводим число жителей в каждом доме
            int[] residents = InputResidents();
            // Рассчитываем общее число жителей
            int totalResidents = CalculateTotalResidents(residents);
            // Находим номер дома с максимальным числом жителей
            int maxResidentsHouse = FindMaxResidentsHouse(residents);
            // Выводим результаты
            OutputResults(totalResidents, maxResidentsHouse);
        }
        ///Массив с числом жителей в каждом доме.</returns>
        static int[] InputResidents()
        {

            int[] residents = new int[12];

            for (int i = 0; i < 12; i++)
            {
                Console.Write($"Введите число жителей в доме {i + 1}: ");
                residents[i] = Convert.ToInt32(Console.ReadLine());
            }

            return residents;

        ///Общее число жителей
        static int CalculateTotalResidents(int[] residents)
        {
            int totalResidents = 0;

            for (int i = 0; i < 12; i++)
            {
                totalResidents += residents[i];
            }

            return totalResidents;
        }
            /// Находит номер дома с максимальным числом жителей.
            static int FindMaxResidentsHouse(int[] residents)
        {
            int maxResidents = residents[0];
            int maxResidentsHouse = 1;

            for (int i = 1; i < 12; i++)
            {
                if (residents[i] > maxResidents)
                {
                    maxResidents = residents[i];
                    maxResidentsHouse = i + 1;
                }
            }

            return maxResidentsHouse;
        }
        /// Выводит результаты.
        static void OutputResults(int totalResidents, int maxResidentsHouse)
        {
            Console.WriteLine($"Общее число жителей в 12 домах: {totalResidents}");
            Console.WriteLine($"Номер дома с максимальным числом жителей: {maxResidentsHouse}");
        }
    }
}



